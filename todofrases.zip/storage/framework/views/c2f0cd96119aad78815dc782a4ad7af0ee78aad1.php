<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <?php if(Session::has('message')): ?>
                <p class="alert alert-danger"><?php echo Session::get('message'); ?></p>
            <?php endif; ?>
            <section class="panel">
                <header class="panel-heading">
                    Agregar frase
                </header>
                <div class="panel-body">
                    <?php echo Form::open(['method' => 'POST','route' => ['phrase.store'],'class'=>'form-horizontal bucket-form']); ?>

                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label class="col-sm-3 control-label">Argegar Frase</label>
                        <div class="col-sm-6">
                            <textarea type="text" name="text" class="form-control" required> </textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Argegar Autor</label>
                        <div class="col-sm-6">
                            <input type="text" name="author" class="form-control" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Elegir Categoria</label>
                        <div class="col-sm-6">
                            <select name="category_id" class="form-control m-bot15" required>
                                <option value="">Categorías</option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->category); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-info">Guardar</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>