<!DOCTYPE HTML>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <title>Todo Frases | Las mejores frases</title>
    <link href="<?php echo e(asset('frontStyle/css/bootstrap.css')); ?>" rel="stylesheet" type="text/css" media="all">
    <link href="<?php echo e(asset('frontStyle/css/style.css')); ?>" rel="stylesheet" type="text/css" media="all"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="keywords" content="Frases de amor, tiempo, piropos, chistes, Arte, cualidades, frases para facebook, frases para whatsapp"/>
    <script type="application/x-javascript"> addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        } </script>
    <link href='http://fonts.googleapis.com/css?family=Varela+Round' rel='stylesheet' type='text/css'>
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.png')); ?>">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="<?php echo e(asset('frontStyle/css/flexslider.css')); ?>" type="text/css" media="screen"/>
    <script src="<?php echo e(asset('frontStyle/js/jquery.min.js')); ?>"></script>
    <link rel="manifest" href="<?php echo e(asset('manifest.json')); ?>" />

    <?php echo $__env->make('front.external.analytics', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('front.external.oneSignal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
    <script>
        (adsbygoogle = window.adsbygoogle || []).push({
            google_ad_client: "ca-pub-7543412924958320",
            enable_page_level_ads: true
        });
    </script>

</head>
<body>
<!-- header -->
<div class="content-main">
    <div class="container">
        <?php echo $__env->make('front.part.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div class="col-md-9 top-right">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <div class="clearfix"></div>
    </div>
</div>
<!-- footer -->
<div class="footer">
    <?php echo $__env->make('front.part.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<!-- footer -->
</body>
</html>