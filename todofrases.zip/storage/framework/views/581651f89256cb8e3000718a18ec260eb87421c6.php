<?php $__env->startSection('content'); ?>
    <?php if(Session::has('message')): ?>
        <p class="alert alert-danger"><?php echo Session::get('message'); ?></p>
    <?php endif; ?>
    <div class="table-agile-info">
        <div class="panel panel-default">
            <div class="panel-heading">
                Cateogrías
            </div>
            <div class="table-responsive">
                <table class="table table-striped b-t b-light">
                    <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Creada</th>
                        <th style="width:30px;">Acción</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($category->category); ?></td>
                            <td><?php echo e($category->created_at); ?></td>
                            <td>
                                <a href="<?php echo e(url('category', $category->id)); ?>" type="submit" class="btn btn-link"><i
                                            class="fa fa-check text-success text-active"></i></a>
                                <?php echo Form::open(['method' => 'DELETE','route' => ['category.destroy', $category->id],'style'=>'display:inline']); ?>

                                <?php echo e(Form::token()); ?>

                                <button type="submit" class="btn btn-link" >
                                    <i class="fa fa-times text-danger text"></i></button>
                                <?php echo Form::Close(); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <footer class="panel-footer">
                <div class="row">
                    <div class="col-sm-7 text-right text-center-xs">
                        <?php echo $categories->render(); ?>

                    </div>
                </div>
            </footer>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>