<?php $__env->startSection('content'); ?>
    <div class="banner">
        <div class="col-md-8 banner-left">
            <h3>Última Frase</h3>
            <p><?php echo e($lastPhrase->text); ?></p>
            <p><b><?php echo e($lastPhrase->author); ?></b></p>
        </div>
        <div class="clearfix"></div>
    </div>
    <!-- banner -->
    <!-- welcome -->
    <div class="welcome">
        <?php echo $__env->make('front.part.ads1', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="welcome-top">
            <div class="col-md-6 welcome-left">
                <div class="view view-tenth">
                    <a href="<?php echo e(url('categoria', $randPhrase1->category_id)); ?>">
                        <div class="inner_content clearfix">
                            <div class="product_image">
                                <img src="<?php echo e(asset('frontStyle/images/img5.jpg')); ?>" class="img-responsive of-my"
                                     alt="img5.jpg"/>
                                <div class="mask">
                                    <h4>Frase Aleatorea</h4>
                                    <p><?php echo e($randPhrase1->text); ?></p>
                                    <p><b><?php echo e($randPhrase1->author); ?></b></p>
                                    <h5>Continuar leyendo...</h5>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-6 welcome-right">
                <div class="view view-tenth">
                    <a href="<?php echo e(url('categoria', $randPhrase2->category_id)); ?>">
                        <div class="inner_content clearfix">
                            <div class="product_image">
                                <img src="<?php echo e(asset('frontStyle/images/img4.jpg')); ?>" class="img-responsive of-my"
                                     alt="img4.jpg"/>
                                <div class="mask">
                                    <h4>Más Frases</h4>
                                    <p><?php echo e($randPhrase2->text); ?></p>
                                    <p><b><?php echo e($randPhrase2->author); ?></b></p>
                                    <h5>Continuar leyendo...</h5>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
        <!-- welcome-bottom -->
        <div class="welcome-bottom">
            <ul>
                <?php $__currentLoopData = $lastPhrasesLists1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lastPhraselist1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <h5><?php echo $lastPhraselist1->text; ?></h5>
                        <b><?php echo e($lastPhraselist1->author); ?></b>
                    </li>
                    <br />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <!-- welcome-bottom -->
    </div>
    <!-- welcome -->
    <div class="should">
        <?php echo $__env->make('front.part.ads2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main_front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>