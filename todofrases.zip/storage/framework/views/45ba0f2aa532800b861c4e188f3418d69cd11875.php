<div class="col-md-3 top-left">
    <div class="logo">
        <a href="index.html"><img src="<?php echo e(asset('frontStyle/images/logo.png')); ?>" class="img-responsive" alt="" /></a>
    </div>
    <h4 class="menn">Menu</h4>
    <label></label>
    <div class="head-nav">
        <span class="menu"> </span>
        <ul>
            <li class="active"><a href="index.html">Home</a></li>
            <li><a href="about.html">About</a></li>
            <li><a href="achives.html">Achives</a></li>
            <li><a href="blog.html">Blog</a></li>
            <li><a href="404.html">Shop</a></li>
            <li><a href="contact.html">Contact</a></li>
            <div class="clearfix"> </div>
        </ul>
        <!-- script-for-nav -->
        <script>
            $( "span.menu" ).click(function() {
                $( ".head-nav ul" ).slideToggle(300, function() {
                    // Animation complete.
                });
            });
        </script>
        <!-- script-for-nav -->
    </div>
    <div class="clearfix"> </div>
    <div class="project">
        <h4>Projects</h4>
        <label></label>
        <ul>
            <li><a href="#">Creative Beacon</a></li>
            <li><a href="#">Design Crawl</a></li>
            <li><a href="#">Free Website templates</a></li>
            <li><a href="#">Web Design Fanatic</a></li>
        </ul>
    </div>
    <div class="project">
        <h4>Services</h4>
        <label></label>
        <ul>
            <li><a href="#">Web design</a></li>
            <li><a href="#">Graphic design</a></li>
            <li><a href="#">Logo design</a></li>
            <li><a href="#">WordpPress</a></li>
            <li><a href="#">Vector graphics</a></li>
        </ul>
    </div>
    <div class="project">
        <h4>Social</h4>
        <label></label>
        <ul>
            <li><a href="#">Twitter</a></li>
            <li><a href="#">Facebook</a></li>
            <li><a href="#">Dribbble</a></li>
            <li><a href="#">Behance</a></li>
        </ul>
    </div>
    <div class="project">
        <h4>Twitter Feed</h4>
        <label></label>
        <p>hey <a href="#">@webfan  </a> just been using James George’s website template. i can’t believe he gives them away!</p>
        <h6>1 day ago</h6>
        <p>Just purchased <a href="#">@creativebeacon's</a> great book: Beautiful Web Design</p>
        <h6>1 day ago</h6>
    </div>
</div>