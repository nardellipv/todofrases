<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <?php if(Session::has('message')): ?>
                <p class="alert alert-danger"><?php echo Session::get('message'); ?></p>
            <?php endif; ?>
            <section class="panel">
                <header class="panel-heading">
                    Agregar categoría
                </header>
                <div class="panel-body">
                    
                    <?php echo Form::open(['method' => 'POST','route' => ['category.store'],'class'=>'form-horizontal bucket-form']); ?>

                    <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label class="col-sm-3 control-label">Categorías existentes</label>
                            <div class="col-sm-6">
                                <select class="form-control m-bot15">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option><?php echo e($category->category); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-3 control-label">Argegar Categoría</label>
                            <div class="col-sm-6">
                                <input type="text" name="category" class="form-control">
                            </div>
                            <button type="submit" class="btn btn-info">Submit</button>
                        </div>
                    <?php echo Form::close(); ?>

                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>