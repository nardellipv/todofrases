<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <?php if(Session::has('message')): ?>
                <p class="alert alert-danger"><?php echo Session::get('message'); ?></p>
            <?php endif; ?>
            <section class="panel">
                <header class="panel-heading">
                    Editar categoría
                </header>
                <div class="panel-body">
                    <?php echo Form::model($phrase, ['method' => 'PATCH','route' => ['phrase.update', $phrase->id], 'class'=>'form-horizontal bucket-form']); ?>

                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label class="col-sm-3 control-label">Editar Categoría</label>
                        <div class="col-sm-6">
                            <select name="category_id" class="form-control m-bot15">
                                <option><?php echo e($phrase->category->category); ?></option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->category); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Editar frase</label>
                        <div class="col-sm-6">
                            <textarea type="text" name="text" class="form-control"><?php echo e($phrase->text); ?></textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Editar Autor</label>
                        <div class="col-sm-6">
                            <input type="text" name="author" class="form-control" value="<?php echo e($phrase->author); ?>">
                        </div>
                        <button type="submit" class="btn btn-info">Editar</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>