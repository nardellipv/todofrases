<?php $__env->startSection('content'); ?>
    <div class="market-updates">
        <div class="col-md-3 market-update-gd">
            <div class="market-update-block clr-block-2">
                <div class="col-md-4 market-update-right">
                    <i class="fa fa-eye"> </i>
                </div>
                <div class="col-md-8 market-update-left">
                    <h4>Frases</h4>
                    <h3><?php echo e($phrase); ?></h3>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <div class="col-md-3 market-update-gd">
            <div class="market-update-block clr-block-1">
                <div class="col-md-4 market-update-right">
                    <i class="fa fa-users"></i>
                </div>
                <div class="col-md-8 market-update-left">
                    <h4>Usuarios</h4>
                    <h3><?php echo e($user); ?></h3>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        
        <div class="clearfix"></div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main_admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>