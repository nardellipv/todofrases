<?php $__env->startSection('content'); ?>
    <?php if(Session::has('message')): ?>
        <p class="alert alert-danger"><?php echo Session::get('message'); ?></p>
    <?php endif; ?>
    <div class="about-content">
        <div class="about-section">
            <div class="about-grid">
                <div class="about-grid2">
                    <h3><?php echo e($category->category); ?></h3>
                    <ul>
                        <?php $__currentLoopData = $phrases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phrase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="#"><?php echo $phrase->text; ?> <b><?php echo e($phrase->author); ?></b></a>
                                <a href="<?php echo e(url('like', $phrase->id)); ?>"><img src="<?php echo e(asset('frontStyle/images/likes.png')); ?>"></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main_front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>