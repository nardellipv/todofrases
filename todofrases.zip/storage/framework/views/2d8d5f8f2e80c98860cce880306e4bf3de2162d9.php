<script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
<script>
    var OneSignal = window.OneSignal || [];
    OneSignal.push(function() {
        OneSignal.init({
            appId: "8b90cc91-ca74-447d-ba85-d1b023082b7f",
            autoRegister: false,
            notifyButton: {
                enable: true,
            },
        });
    });
</script>