<div class="col-md-3 top-left">
    <div class="logo">
        <a href="index.html"><img src="<?php echo e(asset('frontStyle/images/logo.png')); ?>" class="img-responsive" alt=""/></a>
    </div>
    <h4 class="menn">Categorías</h4>
    <label></label>
    <div class="head-nav">
        <span class="menu"> </span>
        <ul>
            <li><a href="<?php echo e(url('/')); ?>">Página Principal</a></li>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(url('categoria', $category->id)); ?>"><?php echo e($category->category); ?></a></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="clearfix"></div>
        </ul>
        <!-- script-for-nav -->
        <script>
            $("span.menu").click(function () {
                $(".head-nav ul").slideToggle(300, function () {
                    // Animation complete.
                });
            });
        </script>
        <!-- script-for-nav -->
    </div>
    <div class="clearfix"></div>
</div>